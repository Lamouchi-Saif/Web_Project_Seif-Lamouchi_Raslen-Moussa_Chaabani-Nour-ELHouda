function toggleDropdown() {
  const dropdown = document.getElementById('user-dropdown');
  dropdown.style.display = dropdown.style.display === 'flex' ? 'none' : 'flex';
}
